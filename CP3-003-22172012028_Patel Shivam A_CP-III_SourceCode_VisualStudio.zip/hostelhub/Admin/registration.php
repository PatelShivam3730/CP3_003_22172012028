
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    } 
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            margin-left:-12px;
            position: fixed;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 92vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }

       /* Main content */
        .content {
            margin-left:260px;
            margin-top:-690px;
            width: 70%;
            flex-grow: 1;
            padding: 20px;
            background-color: #fff;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
        }
        .header h2 {
            margin: 0;
        }
        .header .admin {
            display: flex;
            align-items: center;
        }
        .header .admin i {
            margin-right: 10px;
        }
        .registration {
            border: 1px solid #000;
            padding: 20px;
            margin-bottom: 20px;
        }
        .registration img {
            margin-top: -500px;
            float: right;
            width: 100px;
            height: 100px;
            border: 1px solid #000;
        }
        .registration button {
            padding: 10px 20px;
            margin: 10px 5px 0 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .registration .approve {
            background-color: #00ff00;
        }
        .registration .cancel {
            background-color: #ff0000;
            color: #fff;
        }
  </style>
</head>
</head>
<body>
    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>
            <?php
                session_start();
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
        </div>
    </header>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                        <li class="nav-item"><a class="nav-link active" href="#">𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮</a> </li>
                        <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                        <li class="nav-item"><a class="nav-link" href="manage_user.php"> Manage Users </a> </li>
                        <li class="nav-item"><a class="nav-link" href="course.php">Courses</a> </li>
                        <li class="nav-item"><a class="nav-link" href="room.php">Rooms</a> </li>
                        <li class="nav-item"><a class="nav-link" href="registration.php">Requests</a></li>
                        <li class="nav-item"> <a class="nav-link" href="complaints.php">Check Complaints</a> </li>
                        <li class="nav-item"> <a class="nav-link" href="retrive_pswd.php">Retrieve Password</a> </li>
                        <li class="nav-item"> <a class="nav-link" href="../index.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

   <div class="content">
    <h2>
     Room Requests
    </h2>
    <div class="registration">
    <p>1 </p>
     <p>Username :- Shivam@3730 </p>
      <p>Room Type :- AC Room      Room No :- 101      Bed :- 1</p>
     <p>Name :- Patel Shivam A</p>
     <p>Enrollment No :- 22172012028</p>
     <p> Email ID :- Shivampatel@gnu.ac.in</p>
     <p>DOB :- 13/03/2002      Gender :- Male      Age :- 23</p>
     <p>Category :- ST</p>
     <p>Collage :- UVPCE</p>
     <p>Stream :- CE</p>
     <p>Semester :- VII</p>
     <p>Mobile No :- 7046526862</p>
     <p>Parents Mobile No :- 1235467892</p>
     <p>Address :- Valsad, Gujrat , 396020 </p>
     <!--<img height="300" src="./IMG_0101.png" width="300"/> -->
     <button class="approve">
      Approve
     </button>
     <button class="cancel">
      Cancel
     </button>
    </div>
    </div>
   </div>
  </div>

</body>
</html>