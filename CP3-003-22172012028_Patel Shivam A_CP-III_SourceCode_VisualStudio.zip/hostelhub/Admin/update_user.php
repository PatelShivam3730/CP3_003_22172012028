<?php
// Include your database connection
include '../conne.php';

// Check if a user ID was passed
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Fetch the user's details from the database
    $sql = "SELECT username, name FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
    } else {
        echo "User not found.";
        exit;
    }

    // Handle form submission for updating user details
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $new_username = $_POST['username'];
        $new_name = $_POST['name'];

        // Update user details in the database
        $update_sql = "UPDATE users SET username = ?, name = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssi", $new_username, $new_name, $user_id);

        if ($update_stmt->execute()) {
            echo "User updated successfully!";
            header("Location: user_list.php"); // Redirect back to the user list page
            exit;
        } else {
            echo "Error updating user: " . $conn->error;
        }
    }
} else {
    echo "No user ID provided.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
</head>
<body>

<h2>Update User Details</h2>

<form method="POST" action="">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required><br><br>

    <label for="name">Full Name:</label>
    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required><br><br>

    <button type="submit">Update User</button>
</form>

</body>
</html>
