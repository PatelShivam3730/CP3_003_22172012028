<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostelhub";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST['delete'])) {
    $complaint_id = $_POST['complaint_id'];
    $delete_sql = "DELETE FROM complaints WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $complaint_id);
    if ($stmt->execute()) {
        echo "<script>alert('Complaint deleted successfully');</script>";
    } else {
        echo "<script>alert('Error deleting complaint');</script>";
    }
    $stmt->close();
}
$sql = "SELECT id, student_name, enrollment_no, mobile_no, room_no, complaint_type, other FROM complaints";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    }  
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }

       /* Main content */
       .content{
        margin-top:-650px;
        margin-left:700px;
        padding: 20px;
        display: flex;
        font-family: Arial, sans-serif;
       }
        .w-3/4 {
            width: 75%;
        }
        .complaint-card {
            margin-left: -450px;
            background-color: #fff; 
            color: #000;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
            transition: transform 0.3s ease;
        }
        .complaint-card:hover {
            transform: scale(1.02);
        }
        .complaint-card p {
            margin-bottom: 10px; 
            font-size: 1rem;
            line-height: 1.6;
        }
        .complaint-card strong {
            font-weight: 600;
        }
        .btn-danger {
            background-color: #e74c3c;
            border: none;
            color: white;
            padding: 10px 20px;
            font-size: 0.9rem;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-danger:hover {
            background-color: #c0392b; 
        }
        .no-complaint {
            color: #e74c3c; 
            font-size: 1.5rem;
            font-weight: bold;
            margin-top: 20px;
        }
        @media screen and (max-width: 768px) {
            .w-3/4 {
                width: 100%; 
            }
            .complaint-card {
                padding: 15px;
            }
            .btn-danger {
                width: 100%; 
                padding: 12px;
            }
        }

  </style>
</head>
</head>
<body>
    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>
            <?php 
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'admin@123';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                        <li class="nav-item"><a class="nav-link active" href="#">𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮</a> </li>
                        <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                        <li class="nav-item"><a class="nav-link" href="manage_user.php"> Manage Users </a> </li>
                        <li class="nav-item"><a class="nav-link" href="course.php">Courses</a> </li>
                        <li class="nav-item"><a class="nav-link" href="room.php">Rooms</a> </li>
                        <li class="nav-item"><a class="nav-link" href="registration.php">Requests</a></li>
                        <li class="nav-item"> <a class="nav-link" href="complaints.php">Check Complaints</a> </li>
                        <li class="nav-item"> <a class="nav-link" href="retrive_pswd.php">Retrieve Password</a> </li>
                        <li class="nav-item"> <a class="nav-link" href="../index.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div class="w-3/4 p-10 text-black">
            <div class="flex justify-between items-center mb-4">
                
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <div class="complaint-card">
                            <p><strong>Student Name:</strong> <?php echo $row['student_name']; ?> &nbsp;&nbsp;&nbsp;&nbsp; <strong>Enrollment No:</strong> <?php echo $row['enrollment_no']; ?></p>
                            <p><strong>Mobile No:</strong> <?php echo $row['mobile_no']; ?></p>
                            <p><strong>Room No:</strong> <?php echo $row['room_no']; ?></p>
                            <p><strong>Complaint Type:</strong> <?php echo $row['complaint_type']; ?></p>
                            <p><strong>Other:</strong> <?php echo !empty($row['other']) ? $row['other'] : 'No additional details'; ?></p>
                            
                            <form method="POST" action="" style="display:inline-block;">
                                <input type="hidden" name="complaint_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="delete" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="text-red-600 text-xl no-complaint">No Other Complaints.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php $conn->close(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  
</body>
</html>