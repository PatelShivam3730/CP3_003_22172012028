<?php
session_start(); 
include 'connect.php'; 

if (isset($_POST['signUp'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']); 

    $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $result = $checkEmail->get_result();

    if ($result->num_rows > 0) {
        echo "Email already registered!";
    } else {
        $registerUser = $conn->prepare("INSERT INTO users (name, username, email, password) VALUES (?, ?, ?, ?)");
        $registerUser->bind_param("ssss", $name, $username, $email, $password);
        if ($registerUser->execute()) {
            echo "Registration successful!";
        } else {
            echo "Error: Could not register the user.";
        }
    }
}
?>
