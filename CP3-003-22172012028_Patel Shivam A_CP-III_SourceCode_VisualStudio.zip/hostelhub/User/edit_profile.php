<?php
session_start();
include("../connect.php"); 

$username = $_SESSION['username']; 

$query = "
    SELECT users.*, rooms.room_no, rooms.room_type
    FROM users
    JOIN rooms ON users.id = rooms.id
    WHERE users.username = '$username'
";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result); 
} else {
    echo "Error fetching user data";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    }  
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            width:100%
            position: fixed;
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {     
            position: fixed;
            height: 1100px;
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }
        .main-content {
            margin-top: -1100px;
            margin-left: 260px;
            flex: 1;
            padding: 40px;
            background-color: white;
            border: black; 
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #ccc;
            padding-bottom: 10px;
            margin-bottom: 30px;
        }
        .header h2 {
            font-size: 22px;
        }
        .user-icon {
            width: 40px;
            height: 40px;
            background-color: #ccc;
            border-radius: 50%;
        }
        .profile-details {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        .profile-info {
            max-width: 600px;
            flex: 1;
            margin-right: 20px;
        }
        .profile-info p {
            line-height: 1.6;
        }
        .profile-info p span {
            font-weight: bold;
        }
        .profile-info input[type="text"],
        .profile-info input[type="email"],
        .profile-info input[type="number"],
        .profile-info input[type="date"] {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .profile-picture {
            text-align: center;
            flex-basis: 200px;
        }
        .profile-picture img {
            width: 150px;
            height: 150px;
            background-color: #ddd;
            border-radius: 50%;
            border: 2px solid #ccc;
        }
        .profile-picture input[type="file"] {
            margin-top: 10px;
        }
        .profile-picture button {
            margin-top: 10px;
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        .submit-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .submit-btn:hover {
            background-color: #218838;
        }
        @media (max-width: 768px) {
            .profile-details {
                flex-direction: column;
            }
            .profile-info {
                margin-right: 0;
            }
        }
  </style>
</head>
</head>
<body>
    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>

            <?php
            
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'shivam@3730';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
    
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">  𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮 </a> </li>
                        <li class="nav-item"><a class="nav-link" href="view_profile.php"> View Profile </a> </li>
                        <li class="nav-item"><a class="nav-link" href="edit_profile.php">Edit Profile </a></li>
                        <li class="nav-item"><a class="nav-link" href="request_room.php">  Request For Room </a> </li>
                        <li class="nav-item"><a class="nav-link" href="room_details.php">  Room Details </a> </li>
                        <li class="nav-item"><a class="nav-link" href="complaint.php"> Complaint</a> </li>
                        <li class="nav-item"><a class="nav-link" href="mk_payment.php"> Make Payment </a></li>
                        <li class="nav-item"><a class="nav-link" href="facility.php"> View Facility</a> </li>
                        <li class="nav-item"><a class="nav-link" href="rules.php">Rules & Regulation </a> </li>
                        <li class="nav-item"><a class="nav-link text-logout" href="../index.php"> Logout </a> </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <div class="main-content">
        <form action="edit_profile.php" method="POST" enctype="multipart/form-data">
            <div class="profile-details">
                <div class="profile-info">
                    <p><span>Room No:</span> <?php echo htmlspecialchars($userData['room_no']); ?></p>
                    <p><span>Room Type:</span> <?php echo htmlspecialchars($userData['room_type']); ?></p>
                    <p><span>Name:</span> <input type="text" name="name" value="<?php echo htmlspecialchars($userData['name']); ?>"></p>
                    <p><span>Username:</span> <?php echo htmlspecialchars($userData['username']); ?></p>
                    <p><span>Email ID:</span> <?php echo htmlspecialchars($userData['email']); ?></p>
                    <p><span>DOB:</span> <input type="date" name="dob" value="<?php echo htmlspecialchars($userData['dob']); ?>"></p>
                    <p><span>Gender:</span>  
                        <select name="gender">
                            <option value="Male" <?php echo $userData['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo $userData['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                            <option value="Other" <?php echo $userData['gender'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select> 
                    </p>
                    <p><span>Age:</span> <input type="number" name="age" value="<?php echo htmlspecialchars($userData['age']); ?>"></p>
                    <p><span>Category:</span> 
                        <select name="category">
                            <option value="ST" <?php echo $userData['category'] == 'ST' ? 'selected' : ''; ?>>ST</option>
                            <option value="SC" <?php echo $userData['category'] == 'SC' ? 'selected' : ''; ?>>SC</option>
                            <option value="OBC" <?php echo $userData['category'] == 'OBC' ? 'selected' : ''; ?>>OBC</option>
                            <option value="Others" <?php echo $userData['category'] == 'Others' ? 'selected' : ''; ?>>Others</option>
                        </select>
                    </p>
                    <p><span>Mobile No:</span> <input type="text" name="mobile" value="<?php echo htmlspecialchars($userData['mobile']); ?>"></p>
                    <p><span>Parents Mobile No:</span> <input type="text" name="parents_mobile" value="<?php echo htmlspecialchars($userData['parents_mobile']); ?>"></p>
                    <p><span>Address:</span> <input type="text" name="address" value="<?php echo htmlspecialchars($userData['address']); ?>"></p>
                </div>
            </div>
            <button type="submit" class="submit-btn">Update Profile</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = $_POST['name'];
            $dob = $_POST['dob'];
            $gender = $_POST['gender'];
            $age = $_POST['age'];
            $category = $_POST['category'];
            $mobile = $_POST['mobile'];
            $parents_mobile = $_POST['parents_mobile'];
            $address = $_POST['address'];
            $update_query = "
                UPDATE users 
                SET name='$name', dob='$dob', gender='$gender', age='$age', category='$category', 
                    mobile='$mobile', parents_mobile='$parents_mobile', address='$address' 
                WHERE username='$username'
            ";
            if (mysqli_query($conn, $update_query)) {
                echo "<h1>Profile Updated Successfully</h1>";
            } else {
                echo "Error updating profile: " . mysqli_error($conn);
            }
        }
        ?>
        </div>
    </div>

</body>
</html>     
