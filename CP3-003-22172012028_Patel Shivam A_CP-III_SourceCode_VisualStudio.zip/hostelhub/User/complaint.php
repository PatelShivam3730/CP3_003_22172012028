<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostelhub";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_name = htmlspecialchars($_POST['student_name']);
    $enrollment_no = htmlspecialchars($_POST['enrollment_no']);
    $mobile_no = htmlspecialchars($_POST['mobile_no']);
    $room_no = htmlspecialchars($_POST['room_no']);
    $complaint_type = htmlspecialchars($_POST['complaint_type']);
    $other = isset($_POST['other']) ? htmlspecialchars($_POST['other']) : '';

    $stmt = $conn->prepare("INSERT INTO complaints (student_name, enrollment_no, mobile_no, room_no, complaint_type, other) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $student_name, $enrollment_no, $mobile_no, $room_no, $complaint_type, $other);

    if ($stmt->execute()) {
        $message = "Complaint submitted successfully";
    } else {
        $message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    }
        body, html {
            
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }
        .content{
            width: 70%; 
            margin-top:20px;
            margin-left:50px;
        }
        .bg-white {
            max-width: 500px;
            margin: auto;
        }
        .mb-3
        {
            width: 300px;
        }
  </style>
</head>
</head>
<body>

    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>
            <?php
                session_start();
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'shivam@3730';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
        </div>
    </header>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">  𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮 </a> </li>
                        <li class="nav-item"><a class="nav-link" href="view_profile.php"> View Profile </a> </li>
                        <li class="nav-item"><a class="nav-link" href="edit_profile.php">Edit Profile </a></li>
                        <li class="nav-item"><a class="nav-link" href="request_room.php">  Request For Room </a> </li>
                        <li class="nav-item"><a class="nav-link" href="room_details.php">  Room Details </a> </li>
                        <li class="nav-item"><a class="nav-link" href="complaint.php"> Complaint</a> </li>
                        <li class="nav-item"><a class="nav-link" href="mk_payment.php"> Make Payment </a></li>
                        <li class="nav-item"><a class="nav-link" href="facility.php"> View Facility</a> </li>
                        <li class="nav-item"><a class="nav-link" href="rules.php">Rules & Regulation </a> </li>
                        <li class="nav-item"><a class="nav-link text-logout" href="../index.php"> Logout </a> </li>
                    </ul>
                </div>
            </nav>

<div class="content">
        <h2>Submit Your Complaint</h2>
        <?php if ($message): ?>
            <div class="alert alert-info">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form id="complaintForm" method="POST" action="">
            <div class="mb-3">
                <label for="studentName" class="form-label">Student Name</label>
                <input type="text" name="student_name" class="form-control" id="studentName" placeholder="Enter Your Name" required>
            </div>
            <div class="mb-3">
                <label for="enrollmentNo" class="form-label">Enrollment No</label>
                <input type="text" name="enrollment_no" class="form-control" id="enrollmentNo" placeholder="Enter Your Enrollment No" required>
            </div>
            <div class="mb-3">
                <label for="mobileNo" class="form-label">Mobile No</label>
                <input type="text" name="mobile_no" class="form-control" id="mobileNo" placeholder="Enter Your Mobile No" required>
            </div>
            <div class="mb-3">
                <label for="roomNo" class="form-label">Room No</label>
                <input type="text" name="room_no" class="form-control" id="roomNo" placeholder="Enter Room No" required>
            </div>
            <div class="mb-3">
                <label for="complaintType" class="form-label">Complaint Type</label>
                <select name="complaint_type" class="form-select" id="complaintType" required>
                    <option value="">Select Type</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Water">Water</option>
                    <option value="Cleanliness">Cleanliness</option>
                    <option value="Food">Food</option>
                    <option value="Security">Security</option>
                    <option value="Others">Others</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="otherComplaint" class="form-label">Other</label>
                <input type="text" name="other" class="form-control" id="otherComplaint" placeholder="Type Your Message (Optional)">
            </div>
            <button type="submit" class="btn btn-primary">Send Complaint</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
