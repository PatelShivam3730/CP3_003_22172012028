
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    }
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 90vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }

         /* Main content Styling */
        .flex-1 {
            margin-top: -650px;
            margin-left: 300px;
            flex: 1;
            padding: 2rem;
        }
        .flex.justify-end {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 1rem;
        }
        .flex.justify-end .text-black {
            color: #000;
            font-size: 1.25rem;
            font-weight: bold;
        }
        .space-y-4 > div {
            margin-bottom: 1rem;
        }
        .flex.items-center {
            display: flex;
            align-items: center;
            border: 1px solid #ddd;
            padding: 1rem;
        }
        .w-12.h-12 {
            width: 3rem;
            height: 3rem;
            background-color: #e2e8f0;
            margin-right: 1rem;
            border-radius: 50%; 
        }
        p {
            margin: 0;
        }
        p:first-child {
            font-weight: bold;
            font-size: 1.1rem;
        }
        p:last-child {
            font-size: 0.9rem;
            color: #555;
        }
  </style>
</head>
</head>
<body>
    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>
            <?php
                session_start();
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'Patel Shivam A';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">

            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">  𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮 </a> </li>
                        <li class="nav-item"><a class="nav-link" href="view_profile.php"> View Profile </a> </li>
                        <li class="nav-item"><a class="nav-link" href="edit_profile.php">Edit Profile </a></li>
                        <li class="nav-item"><a class="nav-link" href="request_room.php">  Request For Room </a> </li>
                        <li class="nav-item"><a class="nav-link" href="room_details.php">  Room Details </a> </li>
                        <li class="nav-item"><a class="nav-link" href="complaint.php"> Complaint</a> </li>
                        <li class="nav-item"><a class="nav-link" href="mk_payment.php"> Make Payment </a></li>
                        <li class="nav-item"><a class="nav-link" href="facility.php"> View Facility</a> </li>
                        <li class="nav-item"><a class="nav-link" href="rules.php">Rules & Regulation </a> </li>
                        <li class="nav-item"><a class="nav-link text-logout" href="../index.php"> Logout </a> </li>    
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <div class="flex-1 p-8">
        <div class="space-y-4">
            <div class="flex items-center border p-4">
                <div class="w-12 h-12 bg-gray-200 mr-4"></div>
                 <?php
                        require '../connect.php'; 
                        $query = "SELECT name, age, address FROM users WHERE username = ?";
                        $stmt = $conn->prepare($query);
                        $stmt->bind_param("s", $userName);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                    ?>
                                <div>
                                    <p><?php echo htmlspecialchars($row['name']); ?></p>
                                    <p>Age: <?php echo htmlspecialchars($row['age']); ?></p>
                                    <p>Address: <?php echo htmlspecialchars($row['address']); ?></p>
                                </div>
                            </div>
                    <?php
                        } else {
                            echo "<p>User details not found.</p>";
                        }
                        $stmt->close();
                    ?>
        </div>
    </div>

</body>
</html>
