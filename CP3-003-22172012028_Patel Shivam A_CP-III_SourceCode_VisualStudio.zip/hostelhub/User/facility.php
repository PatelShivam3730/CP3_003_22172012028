

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
      position: fixed;
        top: 0;
        width: 100%;
        z-index: 1000;
    }  
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;   
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            position: fixed;
            top: 56px; 
            left: 0;
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 120vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {  
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }
        .d-flex{
        margin-left:600px;
        color:white;
        }

         /* Main content Styling */
         .main-content {
            margin-top:-900px;
            margin-left:350px
            width: 70%;
            padding: 2rem;
        }
        .main-content .content-box {
            margin-left: 220px;
            width: 70%;
            background-color: white;
            padding: 1.5rem;
            border-radius: 0.25rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
        .main-content ul {
            list-style: disc;
            padding-left: 1.25rem;
        }
        .main-content ul li {
            margin-bottom: 0.5rem;
        }
        .main-content table {
            width: 100%;
            margin-top: 1.5rem;
            border-collapse: collapse;
        }
        .main-content table th,
        .main-content table td {
            border: 1px solid #d1d5db;
            padding: 0.5rem;
        }
        .main-content table thead tr {
            background-color: #fbbf24;
        }
  </style>
</head>
</head>
<body>
    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>
            <?php
                session_start();
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'shivam@3730';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">

            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">  𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮 </a> </li>
                        <li class="nav-item"><a class="nav-link" href="view_profile.php"> View Profile </a> </li>
                        <li class="nav-item"><a class="nav-link" href="edit_profile.php">Edit Profile </a></li>
                        <li class="nav-item"><a class="nav-link" href="request_room.php">  Request For Room </a> </li>
                        <li class="nav-item"><a class="nav-link" href="room_details.php">  Room Details </a> </li>
                        <li class="nav-item"><a class="nav-link" href="complaint.php"> Complaint</a> </li>
                        <li class="nav-item"><a class="nav-link" href="mk_payment.php"> Make Payment </a></li>
                        <li class="nav-item"><a class="nav-link" href="facility.php"> View Facility</a> </li>
                        <li class="nav-item"><a class="nav-link" href="rules.php">Rules & Regulation </a> </li>
                        <li class="nav-item"><a class="nav-link text-logout" href="../index.php"> Logout </a> </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <div class="main-content">
            <div class="content-box">
                <ul>
                    <li><strong>Sports and Recreational Activities :</strong> Students can use GYM and Sports activities like, Volley Ball, Cricket, Foot Ball, Swimming, etc. at Vikram Nail Sports Complex. Professional Coach are available for all the activities.</li>
                    <li><strong>Laundry Service :</strong> Laundry service is available at Campus shopping Centre on the payment basis.</li>
                    <li><strong>Stationery Store and Groceries :</strong> Stationary store is available at the campus shopping campus center. Groceries store is not available on the campus.</li>
                </ul>
                <p class="mt-4">The following arrangements have been made to ensure the security of the inmates of the hostels:</p>
                <ul>
                    <li>Security check at the main gate of each Hostel.</li>
                    <li>Individual security guard at each hostel building.</li>
                </ul>
                <table>
                    <thead>
                        <tr>
                            <th>Sr.No.</th>
                            <th>Hostel Block</th>
                            <th>Hostel Category</th>
                            <th>Hostel Admissions in AY-2024-25</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Boys Hostel New Virtuous</td>
                            <td>AC</td>
                            <td>32000/- Yearly<br>20000/- Sem</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Boys Hostel G & H (Currently not available)</td>
                            <td>Non AC</td>
                            <td>22000/- Yearly<br>14000/- Sem</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>New Oltanjali & Old Oltanjali (In OO Hostel only Non AC available)</td>
                            <td>AC</td>
                            <td>20000/- Yearly<br>12000/- Sem</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>Non Ac</td>
                            <td>15000/- Yearly<br>9000/- Sem</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Armel Mehsana, Preferably for UD Final Year and New PG</td>
                            <td>Non-Ac</td>
                            <td>12000/- Yearly<br>6000/- Sem</td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Food</td>
                            <td>All Boys Hostels</td>
                            <td>15000/- Sem<br>Virtuous 21000/- Sem</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>
