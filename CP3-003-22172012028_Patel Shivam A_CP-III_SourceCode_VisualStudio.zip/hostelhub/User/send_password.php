<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostelhub";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];

$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $token = bin2hex(random_bytes(50));

    $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

    $sql = "UPDATE users SET reset_token = ?, token_expires_at = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $token, $expires_at, $email);
    $stmt->execute();
    $reset_link = "http://yourdomain.com/reset_password.php?token=" . $token;
    $subject = "Password Reset Request";
    $message = "Click on the link below to reset your password: \n\n" . $reset_link;
    $headers = "From: no-reply@yourdomain.com";

    if (mail($email, $subject, $message, $headers)) {
        echo "Password reset link has been sent to your email.";
    } else {
        echo "Failed to send password reset email.";
    }
} else {
    echo "Email not found in our records.";
}

$conn->close();
?>
