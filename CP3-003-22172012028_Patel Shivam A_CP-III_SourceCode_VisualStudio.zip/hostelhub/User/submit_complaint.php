<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";  // Replace with your actual database username
$password = "";      // Replace with your actual database password
$dbname = "hostelhub";  // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo "Connection failed: " . $conn->connect_error;
    exit();
}

// Retrieve form data using POST
$student_name = $_POST['student_name'];
$enrollment_no = $_POST['enrollment_no'];
$mobile_no = $_POST['mobile_no'];
$room_no = $_POST['room_no'];  // Textbox for room number input
$complaint_type = $_POST['complaint_type'];
$other = $_POST['other'];

// Optionally, get the logged-in user's username (if applicable)
$userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'Anonymous';

// Prepare an SQL query to insert data into the complaints table
$sql = "INSERT INTO complaints (student_name, enrollment_no, mobile_no, room_no, complaint_type, other, username)
VALUES ('$student_name', '$enrollment_no', '$mobile_no', '$room_no', '$complaint_type', '$other', '$userName')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    http_response_code(200);  // Success
    echo "Complaint submitted successfully!";
} else {
    http_response_code(500);  // Internal Server Error
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
