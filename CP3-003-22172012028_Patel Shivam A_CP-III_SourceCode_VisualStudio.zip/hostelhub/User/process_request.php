<?php

$host = 'localhost'; 
$db = 'hostelhub'; 
$user = 'root'; 
$pass = ''; 

try {
 
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  
    $inputData = json_decode(file_get_contents('php://input'), true);

  
    if (!isset($inputData['floor'], $inputData['roomType'], $inputData['roomNo'], $inputData['fees'], $inputData['selectedBeds'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid input data']);
        exit;
    }


    $sql = "INSERT INTO room_requests (floor, room_type, room_no, fees,beds_selected) VALUES (:floor, :roomType, :roomNo, :fees, :selectedBeds)";
    $stmt = $pdo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':floor', $inputData['floor']);
    $stmt->bindParam(':roomType', $inputData['roomType']);
    $stmt->bindParam(':roomNo', $inputData['roomNo']);
    $stmt->bindParam(':fees', $inputData['fees']);
    $stmt->bindParam(':selectedBeds', $inputData['selectedBeds']);

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to store data']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
