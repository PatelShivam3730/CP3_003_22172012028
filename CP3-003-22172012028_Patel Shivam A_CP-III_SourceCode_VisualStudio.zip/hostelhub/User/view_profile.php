<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostelhub";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['username'])) {

    header("Location: login.php");
    exit();
}

$loggedInUser = $_SESSION['username'];

$sql = "SELECT * FROM users WHERE username = ?"; 
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $loggedInUser); 
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $userData = $result->fetch_assoc();
} else {
    echo "No user found!";
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    }
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }

         /* Main content Styling */
         .content {
            margin-top: -680px;
            margin-left: 250px;
            padding: 20px;
        }
        .profile {
            margin-top: -650px;
            margin-left: 260px;
            display: flex;
            justify-content: space-between;
        }
        .profile-info {
            width: 70%;
        }
        .profile-info p {
            margin: 5px 0;
            font-size: 18px;
        }
        .profile-info select, .profile-info input {
            margin: 5px 0;
            padding: 5px;
            width: 50%;
            font-size: 16px;
        }
        .profile-info {
            margin: 20px;
            font-family: Arial, sans-serif;
            color: #333;
        }
        .profile-info p {
            margin: 5px 0;
        }
        .profile-info strong {
            color: #003366; 
        }
  </style>
</head>
</head>
<body>
    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>

            <?php  
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'Patel Shivam A';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">

            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                        <li class="nav-item"><a class="nav-link active" href="#">  𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮 </a> </li>
                        <li class="nav-item"><a class="nav-link" href="view_profile.php"> View Profile </a> </li>
                        <li class="nav-item"><a class="nav-link" href="edit_profile.php">Edit Profile </a></li>
                        <li class="nav-item"><a class="nav-link" href="request_room.php">  Request For Room </a> </li>
                        <li class="nav-item"><a class="nav-link" href="room_details.php">  Room Details </a> </li>
                        <li class="nav-item"><a class="nav-link" href="complaint.php"> Complaint</a> </li>
                        <li class="nav-item"><a class="nav-link" href="mk_payment.php"> Make Payment </a></li>
                        <li class="nav-item"><a class="nav-link" href="facility.php"> View Facility</a> </li>
                        <li class="nav-item"><a class="nav-link" href="rules.php">Rules & Regulation </a> </li>
                        <li class="nav-item"><a class="nav-link text-logout" href="../index.php"> Logout </a> </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

<div class="content">

<?php if (isset($userData)): ?>
    <div class="profile-info">
        <p><strong>Username:</strong> <?php echo htmlspecialchars($userData['username']); ?></p>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($userData['name']); ?></p>
        <p><strong>Enrollment No:</strong> <?php echo htmlspecialchars($userData['enrollment_no']); ?></p>
        <p><strong>Email ID:</strong> <?php echo htmlspecialchars($userData['email']); ?></p>
        <p><strong>DOB:</strong> <?php echo htmlspecialchars($userData['dob']); ?></p>
        <p><strong>Gender:</strong> <?php echo htmlspecialchars($userData['gender']); ?></p>
        <p><strong>Age:</strong> <?php echo htmlspecialchars($userData['age']); ?></p>
        <p><strong>Category:</strong> <?php echo htmlspecialchars($userData['category']); ?></p>
        <p><strong>College:</strong> <?php echo htmlspecialchars($userData['college']); ?></p>
        <p><strong>Stream:</strong> <?php echo htmlspecialchars($userData['stream']); ?></p>
        <p><strong>Semester:</strong> <?php echo htmlspecialchars($userData['semester']); ?></p>
        <p><strong>Mobile No:</strong> <?php echo htmlspecialchars($userData['mobile']); ?></p>
        <p><strong>Parents Mobile No:</strong> <?php echo htmlspecialchars($userData['parents_mobile']); ?></p>
        <p><strong>Address:</strong> <?php echo htmlspecialchars($userData['address']); ?></p>
    </div>
<?php else: ?>
    <div class="alert alert-warning" role="alert">
        You are not logged in. Please log in to view your profile.
    </div>
<?php endif; ?>
</div>
</body>
</html>
