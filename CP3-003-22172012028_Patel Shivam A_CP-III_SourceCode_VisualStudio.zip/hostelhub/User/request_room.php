<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar-brand {
            font-family: 'Arial', sans-serif;
            font-size: 4rem;
            color: #ffffff;
            font-weight: bold;
            text-transform: uppercase;
        }
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }
        .content {
            margin-left: 300px;
            margin-top: -650px;
            padding: 20px;
        }
        .bed-status {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        .bed {
            width: 60px;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            border-radius: 5px;
        }
        .booked {
            background-color: red;
            color: white;
        }
        .selected {
            background-color: #32cd32;
        }
        .available {
            background-color: #d3d3d3;
            color: black;
        }
        .mt-6 
        {
            margin-left: 500px;
            margin-top: 50px;
            background-color: #22c55e; 
            color: white;
            padding: 0.75rem; 
            border-radius: 0.25rem; 
        }
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: none; 
        }
        .popup {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%); 
            background-color: white;
            padding: 1.5rem;
            border: 2px solid #22c55e;
            border-radius: 0.5rem; 
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); 
            display: none; 
        }
        .popup button {
            background-color: #22c55e; 
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 0.25rem;
            cursor: pointer;
        }
        .popup button:hover {
            background-color: #16a34a; 
        }
  </style>
</head>
<body>

    <header class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>
            <?php
                
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'shivam@3730';
            ?>
            <div class="d-flex">
                <span class="navbar-text text-light"><?php echo htmlspecialchars($userName); ?></span>
            </div>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">  𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮 </a> </li>
                        <li class="nav-item"><a class="nav-link" href="view_profile.php"> View Profile </a> </li>
                        <li class="nav-item"><a class="nav-link" href="edit_profile.php">Edit Profile </a></li>
                        <li class="nav-item"><a class="nav-link" href="request_room.php">  Request For Room </a> </li>
                        <li class="nav-item"><a class="nav-link" href="room_details.php">  Room Details </a> </li>
                        <li class="nav-item"><a class="nav-link" href="complaint.php"> Complaint</a> </li>
                        <li class="nav-item"><a class="nav-link" href="mk_payment.php"> Make Payment </a></li>
                        <li class="nav-item"><a class="nav-link" href="facility.php"> View Facility</a> </li>
                        <li class="nav-item"><a class="nav-link" href="rules.php">Rules & Regulation </a> </li>
                        <li class="nav-item"><a class="nav-link text-logout" href="../index.php"> Logout </a> </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <div class="content w-3/4">
        <div class="flex items-center mb-4">
            <label class="mr-2">Floor:</label>
            <select id="floor" class="border border-gray-300 p-2 mr-4" onchange="updateRooms()">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>
            <label class="mr-2">Room Type:</label>
            <select id="room-type" class="border border-gray-300 p-2 mr-4" onchange="updateRooms()">
                <option value="ac">AC Room</option>
                <option value="non-ac">Non-AC Room</option>
            </select>
            <label class="mr-2">Room No:</label>
            <select id="room-no" class="border border-gray-300 p-2 mr-4" onchange="updateBeds()"></select>
            <label class="mr-2">Fees:</label>
            <input type="text" id="fees" class="border border-gray-300 p-2" readonly>
        </div>
        <div class="bed-status" id="bed-status"></div>
        <button class="mt-6 " onclick="sendRequest()">Send a Request</button>
    </div>

    <div class="overlay"></div>
    <div class="popup">
        <p>Your request has been sent successfully!</p>
        <button onclick="closePopup()">Close</button>
    </div>

    <script>
        function updateRooms() {
            const floor = document.getElementById('floor').value;
            const roomType = document.getElementById('room-type').value;
            const roomNo = document.getElementById('room-no');
            const fees = document.getElementById('fees');
            roomNo.innerHTML = '';

            let startRoom = (floor - 1) * 10 + (roomType === 'ac' ? 101 : 106);
            for (let i = 0; i < 5; i++) {
                const option = document.createElement('option');
                option.value = startRoom + i;
                option.text = startRoom + i;
                roomNo.appendChild(option);
            }
            fees.value = roomType === 'ac' ? '30,000' : '25,000';
            updateBeds();
        }

        function updateBeds() {
    const bedStatusDiv = document.getElementById('bed-status');
    bedStatusDiv.innerHTML = '';

    const roomNo = document.getElementById('room-no').value;

    const bookedBeds = roomNo == 102 ? [1] : []; 

    const availableBeds = [1, 2, 3, 4];

    availableBeds.forEach(bedNum => {
        const bed = document.createElement('div');
        bed.classList.add('bed');

        if (bookedBeds.includes(bedNum)) {
            bed.classList.add('booked');
            bed.textContent = `Bed ${bedNum} (Booked)`;
            bed.style.pointerEvents = 'none'; 
        } else {
            bed.classList.add('available');
            bed.textContent = `Bed ${bedNum}`;
            bed.onclick = () => toggleSelection(bed); 
        }
        bedStatusDiv.appendChild(bed);
    });
}

        function toggleSelection(element) {
            if (!element.classList.contains('booked')) {
                const isSelected = element.classList.toggle('selected');
                element.classList.toggle('available', !isSelected);
            }
        }

        function sendRequest() {
            const selectedBeds = [];
            const beds = document.querySelectorAll('.bed-status .selected');
            beds.forEach(bed => {
                const bedIndex = Array.from(bed.parentNode.children).indexOf(bed) + 1;
                selectedBeds.push(bedIndex);
            });
            if (selectedBeds.length === 0) {
                alert('Please select at least one bed.');
                return;
            }
            const floor = document.getElementById('floor').value;
            const roomType = document.getElementById('room-type').value;
            const roomNo = document.getElementById('room-no').value;
            const fees = document.getElementById('fees').value;

            fetch('process_request.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    floor: floor,
                    roomType: roomType,
                    roomNo: roomNo,
                    fees: fees,
                    selectedBeds: selectedBeds.join(', ')
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.querySelector('.overlay').classList.remove('hidden');
                    document.querySelector('.popup').classList.remove('hidden');
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Something went wrong, please try again.');
            });
        }

        function closePopup() {
            document.querySelector('.overlay').classList.add('hidden');
            document.querySelector('.popup').classList.add('hidden');
        }
        
        updateRooms();

        function sendRequest() {
            document.querySelector('.overlay').style.display = 'block';
            document.querySelector('.popup').style.display = 'block';
        }

        function closePopup() {
            document.querySelector('.overlay').style.display = 'none';
            document.querySelector('.popup').style.display = 'none';
        }
    </script>

</body>
</html>
        