<?php
include '../connect.php';

$update_user_data = null;  
$search_term = "";   

if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $delete_sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        echo "User deleted successfully!";
    } else {
        echo "Error deleting user: " . $conn->error;
    }
}

if (isset($_GET['edit_user'])) {
    $user_id = $_GET['user_id'];
    $edit_sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($edit_sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $update_user_data = $result->fetch_assoc(); 
    }
}

if (isset($_POST['update_user'])) {
    $user_id = $_POST['user_id'];
    $new_role = $_POST['role'];
    $new_name = $_POST['name'];
    $new_username = $_POST['username'];
    $new_email = $_POST['email'];
    $new_password = $_POST['password'];
    $new_enrollment_no = $_POST['enrollment_no'];
    $new_dob = $_POST['dob'];
    $new_gender = $_POST['gender'];
    $new_age = $_POST['age'];
    $new_category = $_POST['category'];
    $new_college = $_POST['college'];
    $new_stream = $_POST['stream'];
    $new_semester = $_POST['semester'];
    $new_mobile = $_POST['mobile'];
    $new_parents_mobile = $_POST['parents_mobile'];
    $new_address = $_POST['address'];

    $update_sql = "UPDATE users SET role = ?, name = ?, username = ?, email = ?, password = ?, enrollment_no = ?, dob = ?, gender = ?, age = ?, category = ?, college = ?, stream = ?, semester = ?, mobile = ?, parents_mobile = ?, address = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssssssssissssisssi", $new_role, $new_name, $new_username, $new_email, $new_password, $new_enrollment_no, $new_dob, $new_gender, $new_age, $new_category, $new_college, $new_stream, $new_semester, $new_mobile, $new_parents_mobile, $new_address, $user_id);

    if ($stmt->execute()) {
        echo "User updated successfully!";
        header("Location: manage_user.php"); 
        exit;
    } else {
        echo "Error updating user: " . $conn->error;
    }
}

if (isset($_POST['search_user'])) {
    $search_term = $_POST['search_term'];
}

$sql = "SELECT id, username, name FROM users";
if (!empty($search_term)) {
    $sql .= " WHERE username LIKE ? OR name LIKE ?";
    $stmt = $conn->prepare($sql);
    $search_term_param = "%" . $search_term . "%";
    $stmt->bind_param("ss", $search_term_param, $search_term_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql); 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;
      font-weight: bold;
      text-transform: uppercase;
    }    
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            top: 0;
            position: sticky;
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }

       /* Main content */
       .main {
        margin-top:-650px;
        margin-left:300px;
            padding: 20px;
            width: 80%;
        }
        .search-bar input {
            padding: 5px;
            border: 1px solid black;
            border-radius: 5px;
        }
        .search-bar button {
            padding: 5px 10px;
            margin-left: 10px;
            border-radius: 5px;
        }
        .search-bar .update-btn {
            background-color: #00ff00;
        }
        .search-bar .delete-btn {
            background-color: #ff0000;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .manage-buttons button {
            padding: 5px 10px;
            border-radius: 5px;
        }
        .manage-buttons .update-btn {
            margin-top: 10px;
            background-color: #00ff00;
        }
        .manage-buttons .delete-btn {
            background-color: #ff0000;
        }
        .delete-btn {
            background-color: #ff0000; 
            color: white;             
            border: none;            
            padding: 10px 20px;       
            font-size: 16px;           
            border-radius: 5px;        
            cursor: pointer;           
            transition: background-color 0.3s ease; 
        }
        .delete-btn:hover {
            background-color: #e60000;
        }
        .delete-btn:active {
            background-color: #cc0000;
        }
        .delete-btn:focus {
            outline: none;             
            box-shadow: 0 0 5px rgba(166, 0, 0, 0.8); 
        }
        .update-btn {
            background-color: #4CAF50; 
            color: white;              
            border: none;              
            padding: 10px 20px;        
            font-size: 16px;           
            border-radius: 5px;        
            cursor: pointer;           
            transition: background-color 0.3s ease; 
        }
        .update-btn:hover {
            background-color: #45a049; 
        }
        .update-btn:active {
            background-color: #3e8e41; 
        }
        .update-btn:focus {
            outline: none;             
            box-shadow: 0 0 5px rgba(76, 175, 80, 0.8); 
        }
  </style>
</head>
</head>
<body>

    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>
            <?php
                    $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'admin@123';
                    echo htmlspecialchars($userName);
                ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>

        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮</a></li>
                        <li class="nav-item"> <a class="nav-link" href="registration.php">Requests </a>  </li>
                        <li class="nav-item"> <a class="nav-link" href="manage_profile.php">Manage Profile  </a> </li>
                        <li class="nav-item">  <a class="nav-link" href="room.php">Manage Room</a></li>
                        <li class="nav-item"> <a class="nav-link" href="complaints.php">Check Complaints </a> </li>
                        <li class="nav-item"> <a class="nav-link" href="fees.php">Fees Manage </a></li>
                        <li class="nav-item"><a class="nav-link" href="forget_pswd.php">Forget Password</a> </li>
                        <li class="nav-item"> <a class="nav-link text-logout" href="../index.php">Logout</a></li>
                </div>
            </nav>
            
<main class="main">

<div class="search-bar flex items-center"> 
    <form method="POST" action="">
        <label for="search-user" class="mr-2">Search User :</label>
        <input type="text" id="search-user" name="search_term" placeholder="Enter username / Name" value="<?php echo htmlspecialchars($search_term); ?>">
        <button type="submit" name="search_user" class="update-btn">Search</button>
    </form>
</div>
<h2>List of Users</h2>
<table>
    <thead>
        <tr>
            <th>SR.</th>
            <th>Username</th>
            <th>Full Name</th>
            <th>Manage</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            $sr = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $sr . "</td>";
                echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                echo '<td>
                    <form method="POST" action="" style="display:inline-block;">
                        <input type="hidden" name="user_id" value="' . $row['id'] . '">
                        <button type="submit" name="delete_user" class="delete-btn">Delete</button>
                    </form>
                    <form method="GET" action="" style="display:inline-block;">
                        <input type="hidden" name="user_id" value="' . $row['id'] . '">
                        <button type="submit" name="edit_user" class="update-btn">Update</button>
                    </form>
                </td>';
                echo "</tr>";
                $sr++;
            }
        } else {
            echo "<tr><td colspan='4'>No users found</td></tr>";
        }
        ?>
    </tbody>
</table>

<?php if ($update_user_data): ?>
    <h2>Update User Details</h2>
    <form method="POST" action="">
        <input type="hidden" name="user_id" value="<?php echo $update_user_data['id']; ?>">

        <label for="role">Role:</label>
        <input type="text" id="role" name="role" value="<?php echo htmlspecialchars($update_user_data['role']); ?>" required><br><br>

        <label for="name">Full Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($update_user_data['name']); ?>" required><br><br>

        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($update_user_data['username']); ?>" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($update_user_data['email']); ?>" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" value="<?php echo htmlspecialchars($update_user_data['password']); ?>" required><br><br>

        <label for="enrollment_no">Enrollment No:</label>
        <input type="text" id="enrollment_no" name="enrollment_no" value="<?php echo htmlspecialchars($update_user_data['enrollment_no']); ?>" required><br><br>

        <label for="dob">Date of Birth:</label>
        <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($update_user_data['dob']); ?>" required><br><br>

        <label for="gender">Gender:</label>
        <input type="text" id="gender" name="gender" value="<?php echo htmlspecialchars($update_user_data['gender']); ?>" required><br><br>

        <label for="age">Age:</label>
        <input type="number" id="age" name="age" value="<?php echo htmlspecialchars($update_user_data['age']); ?>" required><br><br>

        <label for="category">Category:</label>
        <input type="text" id="category" name="category" value="<?php echo htmlspecialchars($update_user_data['category']); ?>" required><br><br>

        <label for="college">College:</label>
        <input type="text" id="college" name="college" value="<?php echo htmlspecialchars($update_user_data['college']); ?>" required><br><br>

        <label for="stream">Stream:</label>
        <input type="text" id="stream" name="stream" value="<?php echo htmlspecialchars($update_user_data['stream']); ?>" required><br><br>

        <label for="semester">Semester:</label>
        <input type="number" id="semester" name="semester" value="<?php echo htmlspecialchars($update_user_data['semester']); ?>" required><br><br>

        <label for="mobile">Mobile:</label>
        <input type="text" id="mobile" name="mobile" value="<?php echo htmlspecialchars($update_user_data['mobile']); ?>" required><br><br>

        <label for="parents_mobile">Parents' Mobile:</label>
        <input type="text" id="parents_mobile" name="parents_mobile" value="<?php echo htmlspecialchars($update_user_data['parents_mobile']); ?>" required><br><br>

        <label for="address">Address:</label>
        <textarea id="address" name="address" required><?php echo htmlspecialchars($update_user_data['address']); ?></textarea><br><br>

        <button type="submit" name="update_user">Update User</button>
    </form>
<?php endif; ?>

</main>
</body>
</html>
