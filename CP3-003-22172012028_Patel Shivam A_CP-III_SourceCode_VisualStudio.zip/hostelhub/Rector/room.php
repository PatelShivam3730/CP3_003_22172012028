<?php

$pdo = new PDO('mysql:host=localhost;dbname=hostelhub', 'root', '');


if (isset($_POST['add_room'])) {
    $floor_no = $_POST['floor_no'];
    $room_no = $_POST['room_no'];
    $room_type = $_POST['room_type'];
    $fee = $_POST['fee'];
    
    if (!empty($room_no) && !empty($room_type) && !empty($fee)) {
        $addQuery = $pdo->prepare("INSERT INTO rooms (floor_no, room_no, room_type, fee) VALUES (?, ?, ?, ?)");
        $addQuery->execute([$floor_no, $room_no, $room_type, $fee]);

        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

if (isset($_POST['remove_room'])) {
    $room_no = $_POST['remove_room_no'];
    $removeQuery = $pdo->prepare("DELETE FROM rooms WHERE room_no = ?");
    $removeQuery->execute([$room_no]);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

$search_result = [];
if (isset($_POST['search_room'])) {
    $search_room_no = $_POST['search_room_no'];
    $searchQuery = $pdo->prepare("SELECT * FROM rooms WHERE room_no = ?");
    $searchQuery->execute([$search_room_no]);
    $search_result = $searchQuery->fetchAll(PDO::FETCH_ASSOC);
} else {

    $allRoomsQuery = $pdo->prepare("SELECT * FROM rooms");
    $allRoomsQuery->execute();
    $search_result = $allRoomsQuery->fetchAll(PDO::FETCH_ASSOC);
}
?>

<?php
if (isset($_POST['search_room'])) {
    $search_room_no = $_POST['search_room_no'];

    if (!empty($search_room_no)) {
        $query = "SELECT * FROM rooms WHERE room_no = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$search_room_no]);
        $search_result = $stmt->fetchAll();
    } else {
        $query = "SELECT * FROM rooms";
        $stmt = $pdo->query($query);
        $search_result = $stmt->fetchAll();
    }
} else {
    $query = "SELECT * FROM rooms";
    $stmt = $pdo->query($query);
    $search_result = $stmt->fetchAll();
}

$query = "SELECT r.id AS room_id, r.room_no, r.room_type, r.fee, 
                 (SELECT COUNT(*) FROM beds WHERE room_id = r.id AND status = 'Booked') AS booked_beds,
                 (SELECT COUNT(*) FROM beds WHERE room_id = r.id) AS total_beds,
                 b.bed_no, b.status AS bed_status
          FROM rooms r
          LEFT JOIN beds b ON r.id = b.room_id
          ORDER BY r.id, b.bed_no"; 
$result = $pdo->query($query);

$rooms = [];
if ($result->rowCount() > 0) {
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $rooms[$row['room_id']]['room_no'] = $row['room_no'];
        $rooms[$row['room_id']]['room_type'] = $row['room_type'];
        $rooms[$row['room_id']]['fee'] = $row['fee'];
        $rooms[$row['room_id']]['booked_beds'] = $row['booked_beds'];
        $rooms[$row['room_id']]['total_beds'] = $row['total_beds'];
        $rooms[$row['room_id']]['beds'][] = [
            'bed_no' => $row['bed_no'],
            'status' => $row['bed_status']
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    }
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }

       /* Main content */
       .content {
            width: 75%;
            height: 200px;
            margin-left:280px;
            margin-top:-650px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .add-btn, .search-btn, .remove-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            color: white;
        }
        .add-btn {
            background-color: #4CAF50;
        }
        .search-btn {
            background-color: #008CBA;
        }
        .remove-btn {
            background-color: #ff4d4d;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        .list_of_room {
            margin-left: 280px;
            margin-top: -430px;
            width: 75%;
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #ccc;
            padding: 10px;
            background-color: #f9f9f9;
        }
        table {
            width: 100%;  
            border-collapse: collapse; 
        }
        th, td {
            padding: 8px 12px;
            text-align: left;
        }
        thead {
            background-color: #f2f2f2;
            position: sticky; 
            top: 0;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:nth-child(odd) {
            background-color: #fff;
        }
        tbody {
            background-color: #fff;
        }
        .bed-booked {
            background-color: #f8d7da; 
        }
        .bed-available {
            background-color: #d4edda; 
        }
  </style>
</head>
</head>
<body>

    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>
            <?php
                session_start();
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮</a></li>
                        <li class="nav-item"> <a class="nav-link" href="registration.php">Requests </a>  </li>
                        <li class="nav-item"> <a class="nav-link" href="manage_profile.php">Manage Profile  </a> </li>
                        <li class="nav-item">  <a class="nav-link" href="room.php">Manage Room</a></li>
                        <li class="nav-item"> <a class="nav-link" href="complaints.php">Check Complaints </a> </li>
                        <li class="nav-item"> <a class="nav-link" href="fees.php">Fees Manage </a></li>
                        <li class="nav-item"><a class="nav-link" href="forget_pswd.php">Forget Password</a> </li>
                        <li class="nav-item"> <a class="nav-link text-logout" href="../index.php">Logout</a></li>
                    </ul>
                </div>
            </nav>

<div class="content">
    <div class="form-group">
    <form method="POST">
    <input type="text" name="search_room_no" placeholder="Enter Room No">
    <button type="submit" name="search_room" class="search-btn">Search</button>
        </form>
            </div>
            <div class="form-group">
                <form method="POST">
                    <label>Add Room :</label>
                    <input type="text" name="floor_no" placeholder="Enter floor No" required>
                    <input type="text" name="room_no" placeholder="Enter Room No" required>
                    <select name="room_type" required>
                    <option value="" disabled selected>Select Room Type</option>
                    <option value="AC">AC</option>
                    <option value="Non-AC">Non-AC</option>
                    </select>
                    <input type="text" name="fee" placeholder="Enter Fee" required>
                    <button type="submit" name="add_room" class="add-btn">Add</button>
                </form>
            </div>
            <div class="form-group">
                <form method="POST">
                    <label>Remove Room :</label>
                    <input type="text" name="remove_room_no" placeholder="Enter Room No" required>
                    <button type="submit" name="remove_room" class="remove-btn">Remove</button>
                </form>
            </div>
            </div>
<div class="list_of_room">
    <table class="table">
                    <thead>
                        <tr>
                            <th>Room No</th>
                            <th>Type</th>
                            <th>Fee</th>
                            <th>Status</th>
                            <th>Beds</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rooms as $room): ?>
                            <tr class="<?php echo ($room['booked_beds'] == $room['total_beds']) ? 'full' : 'available'; ?>">
                                <td><?php echo htmlspecialchars($room['room_no']); ?></td>
                                <td><?php echo htmlspecialchars($room['room_type']); ?></td>
                                <td><?php echo htmlspecialchars($room['fee']); ?></td>
                                <td>
                                    <?php echo ($room['booked_beds'] == $room['total_beds']) ? "Full" : "Available"; ?>
                                </td>
                                <td>
                                    <ul>
                                        <?php foreach ($room['beds'] as $bed): ?>
                                            <li class="<?php echo ($bed['status'] == 'Booked') ? 'bed-booked' : 'bed-available'; ?>">
                                                Bed <?php echo htmlspecialchars($bed['bed_no']); ?> - <?php echo htmlspecialchars($bed['status']); ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
