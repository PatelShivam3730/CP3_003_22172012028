<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostelhub";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT fees.id, users.name, fees.total_fees, fees.pending_fees, users.mobile, users.carrier, users.email 
        FROM fees 
        JOIN users ON fees.user_id = users.id"; 
$result = $conn->query($sql);

require '../vendor/autoload.php'; 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST['notify_user'])) {
    $user_name = $_POST['user_name'];
    $pending_fees = $_POST['pending_fees'];
    $user_email = $_POST['user_email']; 

    $message = "Dear $user_name, you have pending fees of ₹$pending_fees. Please clear them as soon as possible. otherwise take a strict action";

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'shivampatel19@gnu.ac.in';
        $mail->Password = 'gj15bq3730';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->setFrom('shivampatel19@gnu.ac.in', 'Hostel Hub'); 
        $mail->addAddress($user_email); 
        $mail->isHTML(false);
        $mail->Subject = 'Pending Fees Notification';
        $mail->Body = $message;
        $mail->send();
        echo "<script>alert('Email sent to $user_name!');</script>"; 
    } catch (Exception $e) {
        echo "<script>alert('Failed to send email. Mailer Error: {$mail->ErrorInfo}');</script>"; 
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    }
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            top: 0; 
            position: sticky;
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }

       /* Main content */
       .main {
        margin-top:-670px;
        margin-left:270px;
            padding: 20px;
            width: 80%;
        }
        h2{
            font-size: 2rem; 
            font-weight: bold; 
        }
        .search-bar input {
            padding: 5px;
            border: 1px solid black;
            border-radius: 5px;
        }
        .search-bar button {
            padding: 5px 10px;
            margin-left: 10px;
            border-radius: 5px;
        }
        .search-bar .update-btn {
            background-color: #00ff00;
        }
        .search-bar .delete-btn {
            background-color: #ff0000;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .manage-buttons button {
            padding: 5px 10px;
            border-radius: 5px;
        }
        .manage-buttons .update-btn {
            margin-top: 10px;
            background-color: #00ff00;
        }
        .manage-buttons .delete-btn {
            background-color: #ff0000;
        }
        .delete-btn {
            background-color: #ff0000; 
            color: white;             
            border: none;            
            padding: 10px 20px;       
            font-size: 16px;           
            border-radius: 5px;        
            cursor: pointer;           
            transition: background-color 0.3s ease; 
        }
        .delete-btn:hover {
            background-color: #e60000;
        }
        .delete-btn:active {
            background-color: #cc0000;
        }
        .delete-btn:focus {
            outline: none;             
            box-shadow: 0 0 5px rgba(166, 0, 0, 0.8); 
        }
        .update-btn {
            background-color: #4CAF50; 
            color: white;              
            border: none;              
            padding: 10px 20px;        
            font-size: 16px;           
            border-radius: 5px;        
            cursor: pointer;           
            transition: background-color 0.3s ease; 
        }
        .update-btn:hover {
            background-color: #45a049; 
        }
        .update-btn:active {
            background-color: #3e8e41; 
        }
        .update-btn:focus {
            outline: none;             
            box-shadow: 0 0 5px rgba(76, 175, 80, 0.8); 
        }
        .form{
            width: 40%;
        }
        .content{
            margin-top: 15px;
        }
  </style>
</head>
</head>
<body>

    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">

            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>

            <?php
                    $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'admin@123';
                    echo htmlspecialchars($userName);
                ?>
            <div class="d-flex">
            
        </div>
        
    </header>

    <div class="container-fluid">
        <div class="row">

            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮</a></li>
                        <li class="nav-item"> <a class="nav-link" href="registration.php">Requests </a>  </li>
                        <li class="nav-item"> <a class="nav-link" href="manage_profile.php">Manage Profile  </a> </li>
                        <li class="nav-item">  <a class="nav-link" href="room.php">Manage Room</a></li>
                        <li class="nav-item"> <a class="nav-link" href="complaints.php">Check Complaints </a> </li>
                        <li class="nav-item"> <a class="nav-link" href="fees.php">Fees Manage </a></li>
                        <li class="nav-item"><a class="nav-link" href="forget_pswd.php">Forget Password</a> </li>
                        <li class="nav-item"> <a class="nav-link text-logout" href="../index.php">Logout</a></li>
                </div>
            </nav>

<main class="main">

<div class="form">
<h2>Update Pending Fees:</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="user_id" class="form-label">Select User:</label>
                <select name="user_id" id="user_id" class="form-select" required>
                    <option value="">Choose a user</option>
                    <?php
                    $users_result = $conn->query("SELECT id, name FROM users");
                    if ($users_result->num_rows > 0) {
                        while ($user = $users_result->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($user['id']) . "'>" . htmlspecialchars($user['name']) . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="new_pending_fees" class="form-label">New Pending Fees:</label>
                <input type="number" name="new_pending_fees" id="new_pending_fees" class="form-control" required>
            </div>
            <button type="submit" name="update_fees" class="btn btn-warning">Update Fees</button>
        </form>
        </div>

    <div class="content col-md-10">
        <h2>List of Users:</h2>
        <button onclick="window.location.reload();" class="btn btn-info mb-3">Refresh Table ↻</button>

        <table class="table">
            <tr>
                <th>SR.</th>
                <th>Full Name</th>
                <th>Total Fees</th>
                <th>Pending Fees</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>

            <?php
            $conn = new mysqli($servername, $username, $password, $dbname);
            $sql = "SELECT fees.id, users.name, fees.total_fees, fees.pending_fees, users.email 
                    FROM fees 
                    JOIN users ON fees.user_id = users.id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $sr = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $sr . "</td>
                            <td>" . htmlspecialchars($row['name']) . "</td>
                            <td>" . htmlspecialchars($row['total_fees']) . "</td>
                            <td>" . htmlspecialchars($row['pending_fees']) . "</td>
                            <td>" . htmlspecialchars($row['email']) . "</td>
                            <td>
                                <form method='POST' action=''>
                                    <input type='hidden' name='user_name' value='" . htmlspecialchars($row['name']) . "'>
                                    <input type='hidden' name='pending_fees' value='" . htmlspecialchars($row['pending_fees']) . "'>
                                    <input type='hidden' name='user_email' value='" . htmlspecialchars($row['email']) . "'>
                                    <button type='submit' name='notify_user' class='btn btn-danger'>Notify via Email</button>
                                </form>
                            </td>
                          </tr>";
                    $sr++;
                }
            } else {
                echo "<tr><td colspan='6'>No users found</td></tr>";
            }
            ?>
        </table>
        </div>
</main>

<?php
if (isset($_POST['update_fees'])) {
    $user_id = $_POST['user_id'];
    $new_pending_fees = $_POST['new_pending_fees'];
    $update_sql = "UPDATE fees SET pending_fees = ? WHERE user_id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("di", $new_pending_fees, $user_id); 
    if ($stmt->execute()) {
        echo "<script>alert('Pending fees updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating fees: {$stmt->error}');</script>";
    }
    $stmt->close();
}
?>
    
</body>
</html>
