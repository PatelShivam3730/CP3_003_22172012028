

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    }
          
        body, html {
            height: 70%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }

        .sidebar {
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }

        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }

        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }

        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }

        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }

        .content {
            margin-top:-650px;
            margin-left: 200px;
            padding: 20px;
        }
        .note-box {
            margin-left:100px;
            border: 1px solid black;
            padding: 20px;
            width: 60%;
            margin: 0 auto;
            text-align: center;
        }
        .note-box h2 {
            margin-top: 0;
        }
        .note-box textarea {
            width: 100%;
            height: 100px;
            margin-top: 10px;
        }
        .note-box button {
            background-color: limegreen;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }

  </style>
</head>
</head>
<body>

    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">

            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>

            <?php
            session_start();
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'rector';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
    
        </div>
        
    </header>

    <div class="container-fluid">
        <div class="row">

            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮</a></li>
                        <li class="nav-item"> <a class="nav-link" href="registration.php">Requests </a>  </li>
                        <li class="nav-item"> <a class="nav-link" href="manage_profile.php">Manage Profile  </a> </li>
                        <li class="nav-item">  <a class="nav-link" href="room.php">Manage Room</a></li>
                        <li class="nav-item"> <a class="nav-link" href="complaints.php">Check Complaints </a> </li>
                        <li class="nav-item"> <a class="nav-link" href="fees.php">Fees Manage </a></li>
                        <li class="nav-item"><a class="nav-link" href="forget_pswd.php">Forget Password</a> </li>
                        <li class="nav-item"> <a class="nav-link text-logout" href="../index.php">Logout</a></li>
                    </ul>
                </div>
            </nav>

            <div class="content">
        <div class="note-box">
            <h2>NOTE</h2>
            <textarea></textarea>
            <button>Send Notice</button>
        </div>
    </div>

</body>
</html>
