<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostelhub";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_details = null; 
$error_message = ""; 
if (isset($_POST['search'])) {
    $search_input = $_POST['search_input'];
    $sql = "SELECT id, username, password FROM users WHERE username = ? OR name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $search_input, $search_input);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user_details = $result->fetch_assoc();
        } else {
            $error_message = "User not found!";
        }
    }
    $stmt->close();
}
if (isset($_POST['update_password'])) {
    $user_id = $_POST['user_id'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT); 
    $update_sql = "UPDATE users SET password = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $new_password, $user_id);

    if ($stmt->execute()) {
        echo "<script>alert('Password updated successfully');</script>";
    } else {
        echo "<script>alert('Error updating password');</script>";
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="">
    <style>
    .navbar-brand {
      font-family: 'Arial', sans-serif;
      font-size: 4rem; 
      color: #ffffff;p
      font-weight: bold;
      text-transform: uppercase;
    } 
        body, html {
            height: 70%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: rgb(0 0 0) !important;
        }
        .navbar-brand {
            background-color: #000000;
            font-family: 'Cursive', sans-serif;
            font-size: 2rem;
        }
        .sidebar {
            margin-left: -12px;
            background: linear-gradient(to bottom, #000000, #003366, #0000ff);
            height: 91vh;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            font-size: 1rem;
            color: white;
            padding: 15px 10px;
            border-radius: 10px;
            text-align: center;
        }
        .sidebar .nav-link:hover {
            background-color: #ffffff;
            color: #000;
        }
        .sidebar .nav-link.active {
            background-color: #000000;
            color: #5410fe;
        }
        .sidebar .nav-link.text-danger {
            color:white;
        }
        .sidebar .nav-link.text-logout {
            color: rgb(255 0 0);
        }
        .content {
            margin-top:30px;
            margin-left: 100px;
            width: 30%;
            height: 50%;
            background-color: #2a2a2a;
            padding: 20px;
            color: #fff;
        }
        .content label {
            color: #fff;
        }
        .error-message {
            color: red;
            margin-bottom: 10px;
        }
  </style>
</head>
</head>
<body>
    <header class="navbar navbar-dark bg-dark" >
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">ℍ𝕠𝕤𝕥𝕖𝕝ℍ𝕦𝕓</span>

            <?php
            session_start();
            $userName = isset($_SESSION['username']) ? $_SESSION['username'] : 'rector';
            ?>
            <div class="d-flex">
            <span class="navbar-text text-light" font-size ="2rem" ><?php echo htmlspecialchars($userName); ?></span>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">

            <nav class="col-md-2 d-none d-md-block bg-gradient">
                <div class="position-sticky pt-3 sidebar">
                    <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="#">𝓦𝓮𝓵𝓵𝓬𝓸𝓶𝓮</a></li>
                        <li class="nav-item"> <a class="nav-link" href="registration.php">Requests </a>  </li>
                        <li class="nav-item"> <a class="nav-link" href="manage_profile.php">Manage Profile  </a> </li>
                        <li class="nav-item">  <a class="nav-link" href="room.php">Manage Room</a></li>
                        <li class="nav-item"> <a class="nav-link" href="complaints.php">Check Complaints </a> </li>
                        <li class="nav-item"> <a class="nav-link" href="fees.php">Fees Manage </a></li>
                        <li class="nav-item"><a class="nav-link" href="forget_pswd.php">Forget Password</a> </li>
                        <li class="nav-item"> <a class="nav-link text-logout" href="../index.php">Logout</a></li>
                    </ul>
                </div>
            </nav>

            <div class="content">
    <form method="POST" action="">
        <div class="mb-3">
            <label for="searchInput">Search User:</label>
            <input type="text" id="searchInput" name="search_input" class="form-control" placeholder="Enter Username / Name" required>
            <button type="submit" name="search" class="btn btn-primary mt-2">Search</button>
        </div>
    </form>
    <?php if (!empty($error_message)): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <?php if ($user_details): ?>
        <div class="mb-3">
            <p><strong>Username:</strong> <?php echo $user_details['username']; ?></p>
            <p><strong>View Password:</strong> 
                <input type="password" id="viewPassword" class="form-control d-inline-block" value="<?php echo $user_details['password']; ?>" readonly>
                <input type="checkbox" id="togglePassword"> Show Password
            </p>
        </div>

        <form method="POST" action="">
            <input type="hidden" name="user_id" value="<?php echo $user_details['id']; ?>">
            <div class="mb-3">
                <label for="newPassword">Enter New Password:</label>
                <input type="password" id="newPassword" name="new_password" class="form-control" placeholder="Enter New Password" required>
            </div>
            <div>
                <button type="submit" name="update_password" class="btn btn-success">Done</button>
            </div>
        </form>
    <?php endif; ?>
</div>

<script>
    const togglePassword = document.getElementById('togglePassword');
    const passwordField = document.getElementById('viewPassword');

    togglePassword.addEventListener('change', function() {
        if (this.checked) {
            passwordField.type = 'text';
        } else {
            passwordField.type = 'password'; 
        }
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
